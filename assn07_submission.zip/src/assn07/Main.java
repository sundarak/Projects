package assn07;


import java.util.Scanner;

public class Main {


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Map<String,String> passwordManager = new PasswordManager<>();

        System.out.println("Enter Master Password");
        String masterPassword = scanner.nextLine();

        while (!passwordManager.checkMasterPassword(masterPassword)) {
            System.out.println("Enter Master Password");
            masterPassword = scanner.nextLine();
        }

        String command;
        do {
            System.out.println("Enter a command:");
            command = scanner.nextLine();

            switch (command) {
                case "New password":
                    System.out.println("Enter website name:");
                    String website = scanner.nextLine();
                    System.out.println("Enter password:");
                    String password = scanner.nextLine();
                    passwordManager.put(website, password);
                    System.out.println("New password added");
                    break;

                case "Get password":
                    System.out.println("Enter website name:");
                    String websiteToRetrieve = scanner.nextLine();
                    String retrievedPassword = passwordManager.get(websiteToRetrieve);
                    if (retrievedPassword == null) {
                        System.out.println("Password does not exist");
                    } else {
                        System.out.println(retrievedPassword);
                    }
                    break;

                case "Delete account":
                    System.out.println("Enter website name:");
                    String websiteToDelete = scanner.nextLine();
                    String deletedAccount = passwordManager.remove(websiteToDelete);
                    if (deletedAccount == null) {
                        System.out.println("Account does not exist");
                    } else {
                        System.out.println("Account deleted");
                    }
                    break;

                case "Check duplicate password":
                    System.out.println("Enter password:");
                    String passwordToCheck = scanner.nextLine();
                    var duplicateAccounts = passwordManager.checkDuplicate(passwordToCheck);
                    if (duplicateAccounts.isEmpty()) {
                        System.out.println("No account uses that password");
                    } else {
                        System.out.println("Websites using that password:");
                        for (String websiteName : duplicateAccounts) {
                            System.out.println(websiteName);
                        }
                    }
                    break;

                case "Get accounts":
                    var accounts = passwordManager.keySet();
                    System.out.println("Your accounts:");
                    for (String account : accounts) {
                        System.out.println(account);
                    }
                    break;

                case "Generate random password":
                    System.out.println("Enter length of password:");
                    int length = Integer.parseInt(scanner.nextLine());
                    String generatedPassword = passwordManager.generateRandomPassword(length);
                    System.out.println(generatedPassword);
                    break;

                case "Exit":
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Command not found");
                    break;
            }
        } while (!command.equals("Exit"));

        scanner.close();
    }

}
